import { Metadata } from "next";

export const metadata: Metadata = {
  title: "EcoTrack",
  description: "AI-powered Waste Management Platform",
};
