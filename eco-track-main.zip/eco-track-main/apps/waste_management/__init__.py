from flask import Blueprint

blueprint = Blueprint(
    'waste_management',
    __name__,
    url_prefix=''
)
