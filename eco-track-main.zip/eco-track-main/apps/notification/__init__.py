from flask import Blueprint

blueprint = Blueprint(
    'notification',
    __name__,
    url_prefix=''
)
