from flask import Blueprint

blueprint = Blueprint(
    'collection_route_blueprint',
    __name__,
    url_prefix=''
)
