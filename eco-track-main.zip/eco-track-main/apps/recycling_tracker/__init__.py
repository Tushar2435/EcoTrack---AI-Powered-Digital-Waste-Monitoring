from flask import Blueprint

blueprint = Blueprint(
    'recycling_tracker_blueprint',
    __name__,
    url_prefix=''
)
