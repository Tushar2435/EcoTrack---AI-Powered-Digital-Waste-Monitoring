from flask import Blueprint


blueprint = Blueprint(
    'collection_schedule_blueprint',
    __name__,
    url_prefix=''
)
